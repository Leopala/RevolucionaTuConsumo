package com.app.revolucionatuconsumo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;

public class Hoja02Activity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hoja02);
		
	    Display display = getWindowManager().getDefaultDisplay();

	    DisplayMetrics displaymetrics = new DisplayMetrics ();

	    display.getMetrics(displaymetrics);

	    float dpHeight = displaymetrics.heightPixels;
	    float dpWidth  = displaymetrics.widthPixels;

		Button Button04 = (Button) findViewById(R.id.button04);
		
		Button04.setMinWidth((int) (dpWidth * 0.3));
		Button04.setMinHeight((int) (dpHeight * 0.2));

	}
	
	public void hoja04(View view) {
		
		Intent intent = new Intent(this, Hoja04Activity.class);
		
		startActivity(intent);
		
	}
}
