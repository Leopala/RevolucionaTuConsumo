package com.app.revolucionatuconsumo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class Hoja05Activity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hoja05);
		
	    Display display = getWindowManager().getDefaultDisplay();

	    DisplayMetrics displaymetrics = new DisplayMetrics ();

	    display.getMetrics(displaymetrics);

	    float dpHeight = displaymetrics.heightPixels;
	    float dpWidth  = displaymetrics.widthPixels;

	    
		Button Button06 = (Button) findViewById(R.id.button06);
		Button Button07 = (Button) findViewById(R.id.button07);
		
		RelativeLayout.LayoutParams lp06 = (RelativeLayout.LayoutParams) Button06.getLayoutParams();
		RelativeLayout.LayoutParams lp07 = (RelativeLayout.LayoutParams) Button07.getLayoutParams();

		lp06.topMargin = (int) (dpHeight * 0.46);
		
		Button06.setLayoutParams(lp06);
		Button06.setMinWidth((int) (dpWidth * 0.36));
		Button06.setMinHeight((int) (dpHeight * 0.08));

		lp07.topMargin = (int) (dpHeight * 0.36);
		
		Button07.setLayoutParams(lp07);
		Button07.setMinWidth((int) (dpWidth * 0.36));
		Button07.setMinHeight((int) (dpHeight * 0.08));

	}
	
	public void hoja06(View view) {
		
		Intent intent = new Intent(this, Hoja06Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja07(View view) {
		
		Intent intent = new Intent(this, Hoja07Activity.class);
		
		startActivity(intent);
		
	}
	
}
