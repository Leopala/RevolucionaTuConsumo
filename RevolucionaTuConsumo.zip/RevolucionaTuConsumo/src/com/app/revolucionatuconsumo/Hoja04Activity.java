package com.app.revolucionatuconsumo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;


public class Hoja04Activity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hoja04);
		
	    Display display = getWindowManager().getDefaultDisplay();

	    DisplayMetrics displaymetrics = new DisplayMetrics ();

	    display.getMetrics(displaymetrics);

	    float dpHeight = displaymetrics.heightPixels;
	    float dpWidth  = displaymetrics.widthPixels;

	    
	    Button Button05 = (Button) findViewById(R.id.button05);
	    Button Button03 = (Button) findViewById(R.id.button03);
		Button Button08 = (Button) findViewById(R.id.button08);
		Button Button09 = (Button) findViewById(R.id.button09);
		
		RelativeLayout.LayoutParams lp05 = (RelativeLayout.LayoutParams) Button05.getLayoutParams();
		RelativeLayout.LayoutParams lp03 = (RelativeLayout.LayoutParams) Button03.getLayoutParams();
		RelativeLayout.LayoutParams lp08 = (RelativeLayout.LayoutParams) Button08.getLayoutParams();
		RelativeLayout.LayoutParams lp09 = (RelativeLayout.LayoutParams) Button09.getLayoutParams();

		lp05.topMargin = (int) (dpHeight * 0.30);
		
		Button05.setLayoutParams(lp05);
		Button05.setMinWidth((int) (dpWidth * 0.48));
		Button05.setMinHeight((int) (dpHeight * 0.08));
		
		lp03.topMargin = (int) (dpHeight * 0.38);
		
		Button03.setLayoutParams(lp03);
		Button03.setMinWidth((int) (dpWidth * 0.48));
		Button03.setMinHeight((int) (dpHeight * 0.08));
		
		lp08.topMargin = (int) (dpHeight * 0.48);
		
		Button08.setLayoutParams(lp08);
		Button08.setMinWidth((int) (dpWidth * 0.55));
		Button08.setMinHeight((int) (dpHeight * 0.08));
		
		lp09.topMargin = (int) (dpHeight * 0.55);
		
		Button09.setLayoutParams(lp09);
		Button09.setMinWidth((int) (dpWidth * 0.55));
		Button09.setMinHeight((int) (dpHeight * 0.08));
		
	}	
	
	public void hoja05(View view) {
		
		Intent intent = new Intent(this, Hoja05Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja03(View view) {
		
		Intent intent = new Intent(this, Hoja03Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja08(View view) {
		
		Intent intent = new Intent(this, Hoja08Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja09(View view) {
		
		Intent intent = new Intent(this, Hoja09Activity.class);
		
		startActivity(intent);
		
	}
	
}
