package com.app.revolucionatuconsumo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Hoja10Activity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hoja10);
	}
	
	public void hoja11(View view) {
		
		Intent intent = new Intent(this, Hoja11Activity.class);
		
		startActivity(intent);
		
	}
}
