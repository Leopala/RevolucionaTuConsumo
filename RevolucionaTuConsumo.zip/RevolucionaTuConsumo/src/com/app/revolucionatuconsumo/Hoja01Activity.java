package com.app.revolucionatuconsumo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;


public class Hoja01Activity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hoja01);	
		
	    Display display = getWindowManager().getDefaultDisplay();

	    DisplayMetrics displaymetrics = new DisplayMetrics ();

	    display.getMetrics(displaymetrics);

	    float dpHeight = displaymetrics.heightPixels;
	    float dpWidth  = displaymetrics.widthPixels;

	    
		Button Button02 = (Button) findViewById(R.id.button02);
		Button Button03 = (Button) findViewById(R.id.button03);
		Button Button10 = (Button) findViewById(R.id.button10);
		
		RelativeLayout.LayoutParams lp02 = (RelativeLayout.LayoutParams) Button02.getLayoutParams();
		RelativeLayout.LayoutParams lp03 = (RelativeLayout.LayoutParams) Button03.getLayoutParams();
		RelativeLayout.LayoutParams lp10 = (RelativeLayout.LayoutParams) Button10.getLayoutParams();

		lp02.leftMargin   = (int) (dpWidth * 0.1);
		lp02.bottomMargin = (int) (dpHeight * 0.22);
		
		Button02.setLayoutParams(lp02);
		Button02.setMinWidth((int) (dpWidth * 0.25));
		Button02.setMinHeight((int) (dpHeight * 0.12));
		
		lp03.bottomMargin = (int) (dpHeight * 0.22);
		
		Button03.setLayoutParams(lp03);		
		Button03.setMinWidth((int) (dpWidth * 0.25));
		Button03.setMinHeight((int) (dpHeight * 0.12));
		
		lp10.rightMargin  = (int) (dpWidth * 0.1);
		lp10.bottomMargin = (int) (dpHeight * 0.22);
	
		Button10.setLayoutParams(lp10);
		Button10.setMinWidth((int) (dpWidth * 0.25));
		Button10.setMinHeight((int) (dpHeight * 0.12));
	}	
	
	public void hoja02(View view) {
		
		Intent intent = new Intent(this, Hoja02Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja03(View view) {
		
		Intent intent = new Intent(this, Hoja03Activity.class);
		
		startActivity(intent);
		
	}
	
	public void hoja10(View view) {
		
		Intent intent = new Intent(this, Hoja10Activity.class);
		
		startActivity(intent);
		
	}
	
}
